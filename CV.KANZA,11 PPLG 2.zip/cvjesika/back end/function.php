<?php
$database= mysqli_connect('localhost','root','','srimulyani');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $kelas = $_POST ["kelas"];
    $umur = $_POST ["umur"];
    $no_hp = $_POST ["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $hobi = $_POST ["hobi"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $tambah = "INSERT INTO sri VALUE
    ('','$nama','$kelas','$umur','$no_hp','$tanggal_lahir','$pengalaman','$hobi','$skill','$pendidikan')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM sri where no=$hapus");
    return mysqli_affected_rows($database);
}
function editAdmin($editAdmin){
    $nama =$_POST["nama"];
    $kelas =$_POST["kelas"];
    $umur =$_POST["umur"];
    $no_hp =$_POST["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $hobi = $_POST ["hobi"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $edit = "update admin set
    nama = '$nama',
    kelas ='$kelas',
    umur ='$umur',
    no_hp ='$no_hp',
    tanggal lahir = '$tanggal_lahir',
    pengalaman = '$pengalaman',
    hobi = '$hobi',
    skill ='$skill',
    pendidikan = '$pendidikan',
    where no=$hapus";
    mysqli_query($database,$edit);
    return mysqli_affacted_rows($database);
}

?>