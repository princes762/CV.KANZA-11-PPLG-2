<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM sri");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV SRI MULYANI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="header">
    <div class="gambar"> <img src="sri.png" alt="ini gambar sri">
    </div>
    <?php
    foreach ($cari as $cari2):
    ?>
    <h1><?= $cari2 ['nama'];?></h1>
    <h3><?php echo $cari2['hobi'];?></h3>
    <?php
    endforeach;
    ?>
    </div>
    <div class="main">
    <div class="left">
        <h2>Informasi Identitas</h2>
        <p><strong>NAMA :</strong> SRI MULYANI</p>
        <p><strong>ALAMAT : </strong> <?php echo $cari2['alamat'];?></p>
        <p><strong>NO.TELEPON : </strong><?php echo $cari2 ['no_hp'];?></p>
        <p><strong>SKILL : </strong> <?php echo $cari2['skill'];?></p>
        <h2>Pendidikan</h2>
        <p><strong>Sekolah Dasar : </strong> SD 79</p>
        <p><strong>Sekolah Lanjut Tingkat Pertama : </strong> SMP 08</p>
        <p><strong>Sekolah Menengah Kejuruan : </strong> SMK 6</p>
    </div>
    <div class="right">
        <h2>Pekerjaan</h2>
        <p><strong>Di Rumah : </strong> Mencuci Baju</p>
        <p><strong>DI Sekolah : </strong> BELAJAR</p>
        <h2>Kepribadian</h2>
        <p><strong>Sifat </strong></p>
        <li>Lemah Lembut</li>
        <li>Penyabar</li>
        <li>Tidak Suka Marah-Marah</li>
        <li>Suka Menolong</li>
        <li>Baik Hati</li>
        <li>Ramah</li>
        <li>Tidak Berkata Kasar</li>
    </div>
    </div>
    </div>
</body>
</html>